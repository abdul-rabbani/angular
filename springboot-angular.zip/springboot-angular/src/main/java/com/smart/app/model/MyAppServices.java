package com.smart.app.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "APP_SERVICES")
public class MyAppServices implements Serializable{
	 
   private static final long serialVersionUID = 1L;
  
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
	private int id;
	private String serviceName;
	private String serviceType;
	private String paymentType;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	
	@Override
	public String toString() {
		
		return "[serviceType ="+serviceType+"]";
		
	}
	
	
	

}
