package com.smart.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smart.app.model.MyAppServices;

/**
* Created by abdul on 19/01/19.
*/


@Repository
public interface MyAppDAO extends JpaRepository<MyAppServices, Integer>{

}
