import { Injectable } from '@angular/core';
import { HttpClient} from  '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeApiService {
  API_URL  =  'http://localhost:8088';

   constructor(private  httpClient:  HttpClient) {}
   
   
    addEmployee(employee){
    return  this.httpClient.post(`${this.API_URL}/employee/`,employee);
   }
   
     getEmployees(){
    return  this.httpClient.get(`${this.API_URL}/employee`);
    }
    
   
}
