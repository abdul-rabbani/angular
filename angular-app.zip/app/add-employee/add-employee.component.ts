import { Component, OnInit,Input } from '@angular/core';
import { EmployeeApiService } from  '../employee-api.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss']
})
export class AddEmployeeComponent implements OnInit {

  @Input() employee = { email:'', firstName: '', lastName: '' };

  constructor(private  apiService:  EmployeeApiService) { }

  ngOnInit() {
  }
  
  
 addEmployee(){
   var  employeeobj  = {
    email:  this.employee.email,
    firstName:  this.employee.firstName,
    lastName:  this.employee.lastName
};
this.apiService.addEmployee(employeeobj).subscribe((response) => {
    console.log(response);
});
  
  
}

}
