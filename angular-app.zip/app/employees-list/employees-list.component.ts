import { Component, OnInit } from '@angular/core';
import { EmployeeApiService } from  '../employee-api.service';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.scss']
})
export class EmployeesListComponent implements OnInit {
   private  employees:  Array<object> = [];
   
  constructor(private  apiService:  EmployeeApiService) { }


  ngOnInit() {
    this.getEmployees();
  }
  
  public  getEmployees(){
    this.apiService.getEmployees().subscribe((data:  Array<object>) => {
        this.employees  =  data;
        console.log(data);
    });
    
   
}
 

  

}
